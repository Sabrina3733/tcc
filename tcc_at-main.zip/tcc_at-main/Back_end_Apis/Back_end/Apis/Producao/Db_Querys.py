
Querys={

    "Add_materiais" :"""INSERT INTO materiais_producao (id_prod,id_mat,quantidade) 
                        VALUES (%s,%s,0)"""


}