
#Dicionario para Links de APIs para o projeto
APIServer_Name={

# Links para conexão das APIs  ou Back_end

    "Dados_cadastro":"http://127.0.0.1:5001/Dados_Cadastro",

    "Dados_producao":"http://127.0.0.1:5001/Dados_Producao",

    "Dados_producao_detalhar":"http://127.0.0.1:5001/Dados_Producao_Detalhar",

    "Login":"http://127.0.0.1:5001/Login",

    "Producao":"http://127.0.0.1:5001/Producao",
    
    "Usuario":"http://127.0.0.1:5001/Usuario",

    "Valores":"http://127.0.0.1:5001/Valores"


}